package com.example.musicbox;

import android.media.MediaPlayer;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

/** @noinspection ALL*/
public class MainActivity extends AppCompatActivity {

    private ListView lvPlaylist;
    private TextView songInfo;
    private Button btPlay;
    private MediaPlayer mediaPlayer;
    private int currentSongIndex = -1;

    private String[] songs = {
            "Juice World - Song 1",
            "Juice World - Song 2",
            "Juice World - Song 3",
            "Mauve - Song 4",
            "Mauve - Song 5",
            "Imali - Thatohatsi"
    };

    private int[] songResources = {
            R.raw.song1,  // Add corresponding MP3 files in res/raw/
            R.raw.song2,
            R.raw.song3,
            R.raw.song4,
            R.raw.song5,
            R.raw.imali
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        lvPlaylist = findViewById(R.id.lvPlaylist);
        songInfo = findViewById(R.id.songInfo);
        btPlay = findViewById(R.id.btPlay);

        // Set up ListView
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, songs);
        lvPlaylist.setAdapter(adapter);

        // Handle song selection
        lvPlaylist.setOnItemClickListener((adapterView, view, position, id) -> {
            currentSongIndex = position;
            songInfo.setText("Selected: " + songs[position]);
        });

        // Play button click listener
        btPlay.setOnClickListener(view -> {
            if (currentSongIndex != -1) {
                playSong(currentSongIndex);
            }
        });
    }

    private void playSong(int index) {
        if (mediaPlayer != null) {
            mediaPlayer.release();
        }
        mediaPlayer = MediaPlayer.create(this, songResources[index]);
        mediaPlayer.start();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (mediaPlayer != null) {
            mediaPlayer.release();
            mediaPlayer = null;
        }
    }
}





