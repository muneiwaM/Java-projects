package com.example.collections;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;

    public class DetailActivity extends AppCompatActivity {
        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_detail);

            Intent intent = getIntent();
            int imageRes = intent.getIntExtra("image", 0);

            ImageView imageView = findViewById(R.id.ivDetail);
            imageView.setImageResource(imageRes);
        }
    }
