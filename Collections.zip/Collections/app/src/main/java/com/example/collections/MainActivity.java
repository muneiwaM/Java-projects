package com.example.collections;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private final int[] vintageItems = {
            R.drawable.calculator,
            R.drawable.kitchen,
            R.drawable.mugs,
            R.drawable.refrigerator,
            R.drawable.restuarant,
    };
    String[] imageNames = {
            "Calculator", "Kitchen",  "Mugs", "Refrigerator", "Restaurant"
    };
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        GridView gridView = findViewById(R.id.gvItems);
        gridView.setAdapter(new ImageAdapter(this, vintageItems));

        gridView.setOnItemClickListener((parent, view, position, id) -> {
            int selectedImageRes = vintageItems[position];

            // Debug Toast to verify the resource ID
            String name = imageNames[position];
            Toast.makeText(MainActivity.this, "Selected: " + name, Toast.LENGTH_SHORT).show();

            // Pass the image to DetailActivity
            Intent intent = new Intent(MainActivity.this, DetailActivity.class);
            intent.putExtra("image", selectedImageRes);
            startActivity(intent);
        });

    }

    private static class ImageAdapter extends BaseAdapter {
        private final Context context;
        private final int[] images;

        public ImageAdapter(Context context, int[] images) {
            this.context = context;
            this.images = images;
        }

        @Override
        public int getCount() {
            return images.length;
        }

        @Override
        public Object getItem(int position) {
            return images[position];
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            ImageView imageView;
            if (convertView == null) {
                imageView = new ImageView(context);
                imageView.setLayoutParams(new GridView.LayoutParams(200, 200));
                imageView.setScaleType(ImageView.ScaleType.CENTER_CROP);
                imageView.setPadding(8, 8, 8, 8);
            } else {
                imageView = (ImageView) convertView;
            }
            imageView.setImageResource(images[position]);
            return imageView;
        }
    }
}
