package com.example.registra;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.widget.Toolbar;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private EditText nameEditText;
    private EditText emailEditText;
    private Spinner registrationTypeSpinner;
    private EditText teamNameEditText;
    private Spinner projectCategorySpinner;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.content_main);

        Toolbar toolbar = findViewById(R.id.toolbar);
        if (toolbar != null) {
            setSupportActionBar(toolbar);
        }

        nameEditText = findViewById(R.id.nameEditText);
        emailEditText = findViewById(R.id.emailEditText);
        registrationTypeSpinner = findViewById(R.id.registrationTypeSpinner);
        teamNameEditText = findViewById(R.id.teamNameEditText);
        projectCategorySpinner = findViewById(R.id.projectCategorySpinner);
        Button registerButton = findViewById(R.id.registerButton);

        ArrayAdapter<CharSequence> registrationTypeAdapter = ArrayAdapter.createFromResource(this, R.array.registration_type, android.R.layout.simple_spinner_item);
        registrationTypeAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        registrationTypeSpinner.setAdapter(registrationTypeAdapter);

        ArrayAdapter<CharSequence> projectCategoryAdapter = ArrayAdapter.createFromResource(this, R.array.project_category, android.R.layout.simple_spinner_item);
        projectCategoryAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        projectCategorySpinner.setAdapter(projectCategoryAdapter);

        registrationTypeSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (position == 1) {
                    teamNameEditText.setVisibility(View.VISIBLE);
                } else {
                    teamNameEditText.setVisibility(View.GONE);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        registerButton.setOnClickListener(v -> {
            try {
                // Save data to SharedPreferences
                SharedPreferences prefs = getSharedPreferences("registration_data", MODE_PRIVATE);
                SharedPreferences.Editor editor = prefs.edit();
                editor.putString("name", nameEditText.getText().toString());
                editor.putString("email", emailEditText.getText().toString());
                editor.putString("registration_type", registrationTypeSpinner.getSelectedItem().toString());
                editor.putString("team_name", teamNameEditText.getVisibility() == View.VISIBLE
                        ? teamNameEditText.getText().toString()
                        : "");
                editor.putString("project_category", projectCategorySpinner.getSelectedItem().toString());
                editor.apply(); // save the changes

                // Start the summary activity
                Intent intent = new Intent(MainActivity.this, RegistrationSummaryActivity.class);
                startActivity(intent);
            } catch (Exception e) {
                Toast.makeText(MainActivity.this, "An error occurred: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                Log.e("MainActivity", "Error: ", e);
            }
        });



    }}