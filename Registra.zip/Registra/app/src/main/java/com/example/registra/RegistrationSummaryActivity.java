package com.example.registra;

import android.annotation.SuppressLint;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

public class RegistrationSummaryActivity extends AppCompatActivity {

    private TextView countdownTimerTextView;

    @SuppressLint("SetTextI18n")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.registration_summary);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        TextView nameTextView = findViewById(R.id.nameTextView);
        TextView emailTextView = findViewById(R.id.emailTextView);
        TextView registrationTypeTextView = findViewById(R.id.registrationTypeTextView);
        TextView teamNameTextView = findViewById(R.id.teamNameTextView);
        TextView projectCategoryTextView = findViewById(R.id.projectCategoryTextView);
        countdownTimerTextView = findViewById(R.id.timerTextView);

        SharedPreferences prefs = getSharedPreferences("registration_data", MODE_PRIVATE);

        nameTextView.setText("Name: " + prefs.getString("name", ""));
        emailTextView.setText("Email: " + prefs.getString("email", ""));
        registrationTypeTextView.setText("Registration Type: " + prefs.getString("registration_type", ""));
        teamNameTextView.setText("Team Name: " + prefs.getString("team_name", ""));
        projectCategoryTextView.setText("Project Category: " + prefs.getString("project_category", ""));

        new CountDownTimer(100000, 1000) {
            @Override
            public void onTick(long millisUntilFinished) {
                countdownTimerTextView.setText("Countdown Timer: " + millisUntilFinished / 1000 + " seconds");
            }

            @Override
            public void onFinish() {
                countdownTimerTextView.setText("Countdown Timer: Finished");
            }
        }.start();
    }
}
