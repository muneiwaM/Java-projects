/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package waterbillcalculator;

import java.util.Scanner;

/**
 *
 * @author munei
 */
public class WaterBillCalculator {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in); 
        System.out.print("Enter season (summer/other): "); 
         String season = scanner.next().toLowerCase(); 
         System.out.print("Enter water consumption (in litres): "); 
    double waterConsumption = scanner.nextDouble(); 
    double threshold = season.equals("summer") ? 7000 : 5000; 
    double costPerUnit = season.equals("summer") ? 2.78 : 2.65; 
    double extraCostPerUnit = season.equals("summer") ? 0.62 : 0.50; 
    double discountRate = season.equals("summer") ? 0.12 : 0.20; 
    double basicPayment = 38.00; 
    double waterBill = basicPayment + (waterConsumption * costPerUnit); 
    double extraCharge = 0; 
    
         if (waterConsumption > threshold) { extraCharge = (waterConsumption - threshold) * extraCostPerUnit; waterBill += extraCharge;
        } else { 
        waterBill -= waterBill * discountRate; 
       } double vat = waterBill * 0.15; double finalBill = waterBill + vat; System.out.println("\nWater Bill Details:"); 
        System.out.println("--------------------"); 
        System.out.printf("Season: %s\n", season); 
        System.out.printf("Water Consumption: %.2f litres\n", waterConsumption); 
        System.out.printf("Threshold: %.2f litres\n", threshold); 
        System.out.printf("Cost per Unit: R%.2f\n", costPerUnit); 
        System.out.printf("Extra Cost per Unit: R%.2f\n", extraCostPerUnit); 
        System.out.printf("Basic Payment: R%.2f\n", basicPayment); 
        System.out.printf("Water Bill: R%.2f\n", waterBill); 
        System.out.printf("VAT: R%.2f\n", vat); 
        System.out.printf("Final Bill: R%.2f\n", finalBill); 
        if (waterConsumption <= threshold) 
       { 
       System.out.println("You have used water within the threshold. Well done!");
        } else {
         System.out.println("You have used water above the threshold. Please conserve water."); 
       } 
    } 
}
    
