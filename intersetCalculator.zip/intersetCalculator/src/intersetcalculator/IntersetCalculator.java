/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package intersetcalculator;

/**
 *
 * @author munei
 */
public class IntersetCalculator {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
    }
        // method to calculate simple interest
        public double calculateSimpleInterest(double principal,double rate,double time){
            return (principal*rate*time)/100;
        }
        
        // overload method to calculate simple interest with default time period
        public double calculateSimpleInterest(double principal,double rate){
            return (principal*rate)/100;
        }
        
        // method to calculate compound interest
        public double calculateCompoundInterest(double principal,double rate,double time,int frequency){
            return principal *(Math.pow(1 + rate/frequency * 100), frequency*time) - principal;
        }
    }  
}
