package com.example.notes;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    private ArrayList<Note> notes;
    private NoteAdapter adapter;
    private EditText titleEditText;
    private EditText contentEditText;
    private int selectedPosition;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.note_editor);

        ListView listView = findViewById(R.id.listViewNotes);
        titleEditText = findViewById(R.id.etTittle);
        contentEditText = findViewById(R.id.etContent);

        notes = new ArrayList<>();
        adapter = new NoteAdapter(this, notes);
        listView.setAdapter(adapter);

        loadNotes();

        listView.setOnItemClickListener((parent, view, position, id) -> {
            selectedPosition = position;
            Note note = notes.get(position);
            titleEditText.setText(note.getTitle());
            contentEditText.setText(note.getContent());
        });

        Button saveButton = findViewById(R.id.btnSave);
        saveButton.setOnClickListener(v -> saveNote());

        Button deleteButton = findViewById(R.id.btnDelete);
        deleteButton.setOnClickListener(v -> deleteNote());

        Button createNewNoteButton = findViewById(R.id.btnCreateNewNote);
        createNewNoteButton.setOnClickListener(v -> NewNote());
    }

    private void NewNote() {
        titleEditText.setText("");
        contentEditText.setText("");
        selectedPosition = -1;
    }

    private void deleteNote() {
        if (selectedPosition != -1 && selectedPosition < notes.size()) {
            notes.remove(selectedPosition);
            adapter.notifyDataSetChanged();
            selectedPosition = -1;
            titleEditText.setText("");
            contentEditText.setText("");
            // Save notes to persistent storage
        }
    }

    private void loadNotes() {
        // Load notes from persistent storage
        SharedPreferences prefs = getSharedPreferences("notes", MODE_PRIVATE);
        int noteCount = prefs.getInt("noteCount", 0);
        for (int i = 0; i < noteCount; i++) {
            String title = prefs.getString("note" + i + "title", "");
            String content = prefs.getString("note" + i + "content", "");
            notes.add(new Note(title, content));
        }
        adapter.notifyDataSetChanged();
    }

    private void saveNote() {
        String title = titleEditText.getText().toString();
        String content = contentEditText.getText().toString();
        notes.add(new Note(title, content));
        adapter.notifyDataSetChanged();

        // Save notes to persistent storage
        SharedPreferences prefs = getSharedPreferences("notes", MODE_PRIVATE);
        SharedPreferences.Editor editor = prefs.edit();
        editor.putInt("noteCount", notes.size());
        for (int i = 0; i < notes.size(); i++) {
            editor.putString("note" + i + "title", notes.get(i).getTitle());
            editor.putString("note" + i + "content", notes.get(i).getContent());
        }
        editor.apply();
    }
}

